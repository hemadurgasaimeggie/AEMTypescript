import React from 'react';
import FormRenderer from './AdaptiveForm'; // Adjust the import path as needed
import jsonData from '../form-model.json';

const FormContainer = () => {

  return (
    <div>
      <div style={{ border: '2px solid #000', padding: '20px' }}>
        <FormRenderer />
      </div>
    </div>
  );
};

export default FormContainer;
