import React, { useState, useEffect, ReactNode } from "react";
import {
  TextField,
  Button,
  Select,
  MenuItem,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Tabs,
  Tab,
  Tooltip,
  Checkbox,
  InputAdornment,
  Slider,
} from "@mui/material";
import jsonData from "../form-model.json";

interface FormItem {
  value: string | TrustedHTML;
  events: any;
  description: ReactNode;
  id: string;
  fieldType: string;
  name: string;
  visible: boolean;
  label: {
    visible: boolean;
    value: string;
  };
  ":itemsOrder": string[];
  ":items": FormItem[];
  enum: string[];
  enumNames: string[];
  pattern: string;
  patternMessage: string;
  required: boolean;
  default: string;
  minimum: number;
  maximum: number;
  step: number;
  constraintMessages: {
    pattern: ReactNode;
    minimum: string;
    maximum: string;
  };
}

const FormRenderer: React.FC = () => {
    interface Panel {
        id: string;
        fieldType: string;
        name: string;
        visible: boolean;
        enabled: boolean;
        readOnly: boolean;
        columnClassNames: {
          [key: string]: string;
        };
        // Add other properties as needed
      }
      
      interface JsonStructure {
        // Add other properties as needed
        ":items": {
          [key: string]: Panel;
        };
        // Add other properties as needed
      }
         
  const json = jsonData?.[":items"]?.tabsontop;
  const jsons = jsonData?.[":items"]?.panelcontainer;
  const [formData, setFormData] = useState<Record<string, string | string[]>>(
    {}
  );
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [activeTab, setActiveTab] = useState<number>(0);
  const [eventPayload, setEventPayload] = useState<
    Record<string, string | undefined>
  >({});
  useEffect(() => {
    // Your useEffect logic here
  }, [json]);

  const handleChange = (name: string, value: string | string[]) => {
    // Update the formData state
    setFormData({ ...formData, [name]: value });
    const updatedPayload: Record<string, string | undefined> = {
      ...eventPayload,
      [name]: value,
    } as Record<string, string | undefined>;
    setEventPayload(updatedPayload);

    // Set errors if any
    setErrors({ ...errors });
  };
  
  const renderField = (
    item: FormItem,
    totalTextFields: number
  ): JSX.Element => {
    const errorMessage: any = errors[item?.name];
    const hasValidationError =
      errorMessage && errorMessage.validationExpression;
    const hasPatternError = errorMessage && errorMessage.pattern;
    switch (item?.fieldType) {
      case "text-input":
        return (
          <Tooltip title={item?.description} arrow key={item.name}>
            <TextField
              sx={{ mb: 2 }}
              style={{ width: "49%", marginRight: "1%" }}
              label={item.label.value}
              required={item.required}
              value={formData[item.name] || ""}
              onChange={(e) => handleChange(item.name, e.target.value)}
              error={hasValidationError || hasPatternError}
            helperText={
              hasPatternError ? item?.constraintMessages?.pattern: errorMessage?.required
            }
            inputProps={{
              pattern: item.pattern || undefined,
            }}
              InputProps={{
                endAdornment: hasValidationError && (
                  <InputAdornment position="end">
                    {errorMessage.validationExpression}
                  </InputAdornment>
                ),
              }}
            />
          </Tooltip>
        );
      case "number-input":
        return (
          <Tooltip title={item?.description} arrow key={item.name}>
            <TextField
              sx={{ mb: 2, ml: 2 }}
              type="number"
              label={item?.label?.value}
              style={{ width: "45%" }}
              required={item?.required}
              defaultValue={item?.default}
              value={formData[item?.name]}
              onChange={(e) => handleChange(item?.name, e.target.value)}
              error={!!errorMessage}
              helperText={errorMessage}
            />
          </Tooltip>
        );
      case "drop-down":
        return (
          <Tooltip title={item?.description} arrow key={item.name}>
            <Select
              sx={{ mb: 2 }}
              value={formData[item?.name] || ""}
              onChange={(e) => handleChange(item?.name, e.target.value)}
              style={{ width: "49%", marginRight: "1%" }}
              displayEmpty
              renderValue={(selected) =>
                selected ? selected : item?.label?.value
              }
            >
              {item?.enum.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </Select>
          </Tooltip>
        );
      case "checkbox-group":
        if (item?.enum && item?.enumNames) {
          return (
            <div
              key={item?.name}
              style={{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
                marginBottom: "10px",
              }}
            >
              {item?.enum.map((option, index) => (
                <div
                  key={option}
                  style={{
                    marginRight: "10px",
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <Checkbox
                    checked={formData[item?.name]?.includes(option) || false}
                    onChange={(e) => {
                      const isChecked = e.target.checked;
                      const updatedFormData = {
                        ...formData,
                        [item?.name]: isChecked
                          ? Array.isArray(formData[item?.name])
                            ? [...(formData[item?.name] as string[]), option]
                            : [formData[item?.name] as string, option]
                          : Array.isArray(formData[item?.name])
                          ? (formData[item?.name] as string[]).filter(
                              (selectedOption: string) =>
                                selectedOption !== option
                            )
                          : formData[item?.name] === option
                          ? undefined
                          : formData[item?.name],
                      };
                      handleChange(
                        item?.name,
                        (updatedFormData[item?.name] || []) as string | string[]
                      );
                    }}
                  />
                  <Typography>{item?.enumNames[index]}</Typography>
                </div>
              ))}
            </div>
          );
        }
        return <div/>
      case "button":
        return (
          <Button
            sx={{ mb: 2, marginLeft: 2, alignItems: "center" }}
            key={item?.name}
            variant="contained"
            onClick={() => handleButtonClick(item)}
          >
            {item?.label?.value}
          </Button>
        );
      case "plain-text":
        return (
          <Typography
            variant="body1"
            key={item.name}
            sx={{ mb: 2 }}
            dangerouslySetInnerHTML={{ __html: item.value }}
          />
        );
      case "panel":
        return (
          <Accordion
            key={item.id}
            sx={{ mb: 2, width: "99%" }}
            style={{ marginLeft: "6px" }}
          >
            <AccordionSummary>{item.label.value}</AccordionSummary>
            <AccordionDetails>
              <div>
                {item[":itemsOrder"] &&
                  item[":itemsOrder"].map((panelKey: any) => {
                    const panel = item[":items"][panelKey];
                    return (
                      <div key={panel.id}>
                        {panel[":itemsOrder"] &&
                          panel[":itemsOrder"].map((fieldKey: any) => {
                            const field = panel[":items"][fieldKey];
                            return renderField(field, totalTextFields);
                          })}
                      </div>
                    );
                  })}
              </div>
            </AccordionDetails>
          </Accordion>
        );
      default:
        return <div />;
    }
  };

  const handleTabChange = (_event: React.SyntheticEvent, _newValue: number) => {
    // Your handleTabChange logic here
  };

  const handleButtonClick = (item: FormItem) => {
    if (item?.events?.click) {
      const fieldNames: string[] = []; // Declare outside the loop
      item.events.click.forEach((event: string) => {
        const matches = event.match(
          /dispatchEvent\(\$form\.(.*?)\.(.*?)\.(.*?),\s*'custom:setProperty',\s*{value\s*:\s*`(.*?)`}\)/
        );
        if (matches && matches.length === 5) {
          const formName = matches[1];
          const panelIndex = matches[2];
          const fieldName = matches[3];
          const fieldValue = matches[4];

          // Add fieldName to the array
          fieldNames.push(fieldName);

          // Dispatch the event
          const isFieldInEventPayload =
            Object.keys(eventPayload).includes(fieldName);
          if (!isFieldInEventPayload) {
            setEventPayload({});
            setFormData({});
          }

          console.log(fieldNames); // Array containing all field names
          console.log(eventPayload); // Last matched fieldName
        }
      });
    }
  };
  const items: Record<string, any> = json[":items"];
  const itemsOrder: string[] = json[":itemsOrder"];

  return (
    <div>
      <Tabs value={activeTab} onChange={handleTabChange}>
        {json &&
          json[":itemsOrder"].map((tabKey: string, tabIndex: number) => {
            // @ts-ignore
            const tab: any = json[":items"][tabKey]; // Assuming 'tab' can have any type
            return (
              <Tab
                key={tab.id}
                label={tab.label?.value || ""}
                onClick={() => setActiveTab(tabIndex)}
              />
            );
          })}
      </Tabs>
      {json &&
        json[":itemsOrder"] &&
        json[":itemsOrder"].map((tabKey: string, tabIndex: number) => {
            // @ts-ignore
          const tab: any = json[":items"][tabKey]; // Assuming 'tab' can have any type
          return (
            <div key={tab.id} hidden={activeTab !== tabIndex}>
              {tab[":itemsOrder"] && (
                <div>
                  {tab[":itemsOrder"].map((panelKey: string, panelIndex: number) => {
                    const panel: any = tab[":items"][panelKey];
                    // Assuming 'panel' can have any type
                    console.log(panel?.constraintMessages?.pattern)
                    return renderField(panel,0);
                  })}
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      marginTop: "10px",
                    }}
                  >
                    {jsons &&
                      jsons[":itemsOrder"].map((buttonKey: string) => {
                        // @ts-ignore
                        const button: any = jsons[":items"][buttonKey]; // Assuming 'button' can have any type
                        return renderField(button,0);
                      })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
    </div>
  );
  
}
export default FormRenderer;
