import React from 'react';
import AdaptiveForm from './components/AdaptiveForm';
import jsonData from './form-model.json'
import FormContainer from './components/FormContainer';
function App() {
 
const json= jsonData?.[":items"]?.tabsontop;

  return (
    <div className="App">
      <FormContainer />
    </div>
  );
}

export default App;
